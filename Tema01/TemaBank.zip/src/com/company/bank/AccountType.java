package com.company.bank;

public enum AccountType {
    NORMAL_ACCOUNT,
    LIMITED_TRANSACTIONS_ACCOUNT,
    SAVINGS_ACCOUNT
}
